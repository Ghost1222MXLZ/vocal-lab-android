# Vocal Lab

纯本地 Android 声音/歌唱分析工具 MVP。

## 当前功能
- 本地导入音频
- 保存歌曲名、歌手、URI
- 歌曲库
- 读取音频时长、采样率、声道
- 预留 F0/音高、RMS 等分析框架
- GitHub Actions 自动构建 APK

## 手机构建
将项目上传到 GitHub 后，Actions 会自动运行 `Build Vocal Lab APK`。
完成后在 Actions 对应运行记录的 Artifacts 中下载 `VocalLab-debug`。

## 后续
加入 PCM 解码、YIN/pYIN 音高检测、FFT 频谱、声谱图、jitter/shimmer/HNR、歌手对比与本地数据库。
