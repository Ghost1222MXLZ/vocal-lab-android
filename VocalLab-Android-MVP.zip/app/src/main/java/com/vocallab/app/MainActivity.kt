package com.vocallab.app

import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min

data class Song(val id: Long, val title: String, val singer: String, val uri: Uri?)
data class Analysis(val duration: String, val sampleRate: Int, val channels: Int, val note: String, val rmsDb: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VocalLabApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VocalLabApp() {
    var songs by remember { mutableStateOf(listOf<Song>()) }
    var showAdd by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Song?>(null) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Vocal Lab") }) },
            floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }) { Icon(Icons.Default.Add, "添加歌曲") }
            }
        ) { padding ->
            if (selected != null) {
                AnalysisScreen(selected!!, onBack = { selected = null })
            } else {
                Column(Modifier.padding(padding).fillMaxSize().padding(16.dp)) {
                    Text("本地歌曲库", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.height(8.dp))
                    Text("所有歌曲信息只保存在本机。", style = MaterialTheme.typography.bodyMedium)
                    Spacer(Modifier.height(16.dp))
                    if (songs.isEmpty()) {
                        Card(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(20.dp)) {
                                Icon(Icons.Default.MusicNote, null)
                                Spacer(Modifier.height(8.dp))
                                Text("还没有歌曲")
                                Text("点击右下角 + 导入音频并填写歌手。")
                            }
                        }
                    }
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(songs) { song ->
                            Card(onClick = { selected = song }, modifier = Modifier.fillMaxWidth()) {
                                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Icon(Icons.Default.MusicNote, null)
                                    Column(Modifier.weight(1f)) {
                                        Text(song.title, style = MaterialTheme.typography.titleMedium)
                                        Text(song.singer)
                                    }
                                    Icon(Icons.Default.Analytics, null)
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAdd) {
            AddSongDialog(
                onDismiss = { showAdd = false },
                onAdd = { title, singer, uri ->
                    val next = (songs.maxOfOrNull { it.id } ?: 0L) + 1L
                    songs = songs + Song(next, title, singer, uri)
                    showAdd = false
                }
            )
        }
    }
}

@Composable
fun AddSongDialog(onDismiss: () -> Unit, onAdd: (String, String, Uri?) -> Unit) {
    var title by remember { mutableStateOf("") }
    var singer by remember { mutableStateOf("") }
    var uri by remember { mutableStateOf<Uri?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) {
        uri = it
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("添加歌曲") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("歌曲名") }, singleLine = true)
                OutlinedTextField(singer, { singer = it }, label = { Text("歌手") }, singleLine = true)
                Button(onClick = { picker.launch(arrayOf("audio/*")) }) {
                    Text(if (uri == null) "选择音频文件" else "已选择音频")
                }
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && singer.isNotBlank() && uri != null,
                onClick = { onAdd(title.trim(), singer.trim(), uri) }) { Text("添加") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("取消") } }
    )
}

@Composable
fun AnalysisScreen(song: Song, onBack: () -> Unit) {
    var analysis by remember { mutableStateOf<Analysis?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← 返回歌曲库") }
        Text(song.title, style = MaterialTheme.typography.headlineSmall)
        Text(song.singer, style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(16.dp))
        Button(onClick = { analysis = song.uri?.let { analyzeAudio(it) } }) {
            Icon(Icons.Default.Analytics, null)
            Spacer(Modifier.width(8.dp))
            Text("开始分析")
        }
        Spacer(Modifier.height(16.dp))
        analysis?.let { a ->
            MetricCard("时长", a.duration)
            MetricCard("采样率", "${a.sampleRate} Hz")
            MetricCard("声道", "${a.channels}")
            MetricCard("估计音高", a.note)
            MetricCard("RMS响度代理", "${a.rmsDb} dBFS")
        }
    }
}

@Composable
fun MetricCard(name: String, value: String) {
    Card(Modifier.fillMaxWidth().padding(bottom = 8.dp)) {
        Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(name)
            Text(value, style = MaterialTheme.typography.titleMedium)
        }
    }
}

fun analyzeAudio(uri: Uri): Analysis {
    // MVP: metadata + a lightweight amplitude estimate from decoded PCM would be added next.
    // MediaExtractor safely reads common container metadata without requiring network access.
    return try {
        val context = AppHolder.context
        val ex = MediaExtractor()
        ex.setDataSource(context, uri, null)
        var sr = 0; var ch = 0; var durUs = 0L
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                sr = if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) f.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 0
                ch = if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 0
                durUs = if (f.containsKey(MediaFormat.KEY_DURATION)) f.getLong(MediaFormat.KEY_DURATION) else 0L
                break
            }
        }
        ex.release()
        Analysis(formatDuration(durUs), sr, ch, "待进行 F0 音高检测", "待解码")
    } catch (_: Exception) {
        Analysis("--:--", 0, 0, "无法读取", "无法读取")
    }
}

fun formatDuration(us: Long): String {
    val sec = max(0L, us / 1_000_000L)
    return String.format(Locale.US, "%02d:%02d", sec / 60, sec % 60)
}

object AppHolder {
    lateinit var context: android.content.Context
}
