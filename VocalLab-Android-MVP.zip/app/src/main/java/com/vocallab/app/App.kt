package com.vocallab.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        AppHolder.context = applicationContext
    }
}
